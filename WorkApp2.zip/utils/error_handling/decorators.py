# Error handling decorators
import functools
import logging
import time
import traceback
from typing import Callable, Any, Optional, Type, Union, List, Dict

# Setup logging
logger = logging.getLogger(__name__)

# Define specific exception types for better error handling
class RetryableError(Exception):
    """Base class for errors that should be retried"""
    pass

class ConfigurationError(Exception):
    """Error related to configuration issues"""
    pass

class IndexOperationError(Exception):
    """Error related to index operations"""
    pass

class APIError(RetryableError):
    """Error related to external API calls"""
    pass

class NetworkError(RetryableError):
    """Error related to network connectivity"""
    pass

def with_retry(max_attempts: int = 3, backoff_factor: float = 2.0, 
               exception_types: Optional[Union[Type[Exception], List[Type[Exception]]]] = None,
               context: str = "",
               propagate_final_exception: bool = True,
               add_context_to_exception: bool = True):
    """
    Decorator for functions that should be retried on failure with improved error propagation
    
    Args:
        max_attempts: Maximum number of retry attempts
        backoff_factor: Exponential backoff factor between retries
        exception_types: Specific exception types to catch and retry
                        If None, catches RetryableError and its subclasses
        context: Additional context information for error messages
        propagate_final_exception: Whether to propagate the final exception after all retries fail
        add_context_to_exception: Whether to add retry context to the exception message
    
    Returns:
        Decorated function with retry logic
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Default to RetryableError if no exception types specified
            exceptions_to_catch = exception_types or RetryableError
            last_exception = None
            context_info = f" [{context}]" if context else ""
            
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions_to_catch as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        wait_time = backoff_factor ** attempt
                        logger.warning(
                            f"Attempt {attempt+1}/{max_attempts} failed for {func.__name__}{context_info}: {str(e)}. "
                            f"Retrying in {wait_time:.2f}s..."
                        )
                        time.sleep(wait_time)
                    else:
                        logger.error(
                            f"All {max_attempts} attempts failed for {func.__name__}{context_info}: {str(e)}"
                        )
            
            # If we get here, all attempts failed
            if last_exception:
                if propagate_final_exception:
                    # Add more context to the exception if configured
                    if add_context_to_exception:
                        error_msg = f"Failed after {max_attempts} attempts{context_info}: {str(last_exception)}"
                        raise type(last_exception)(error_msg) from last_exception
                    else:
                        # Re-raise the original exception
                        raise last_exception
                else:
                    # Log the error but don't propagate
                    logger.error(f"Suppressing exception after {max_attempts} failed attempts: {str(last_exception)}")
                    return None
            else:
                # This should never happen if last_exception is properly tracked
                error_msg = f"Failed after {max_attempts} attempts{context_info} with unknown error"
                if propagate_final_exception:
                    raise RuntimeError(error_msg)
                else:
                    logger.error(error_msg)
                    return None
        
        return wrapper
    
    return decorator

def with_error_handling(default_return_value: Any = None, 
                       log_level: str = "error",
                       exception_types: Optional[Union[Type[Exception], List[Type[Exception]]]] = None,
                       include_traceback: bool = False,
                       context: str = "",
                       propagate_exceptions: Optional[Union[Type[Exception], List[Type[Exception]]]] = None):
    """
    Decorator for functions that should handle errors gracefully with improved error propagation
    
    Args:
        default_return_value: Value to return if an exception occurs
        log_level: Logging level for exceptions ("debug", "info", "warning", "error", "critical")
        exception_types: Specific exception types to catch
                        If None, catches all exceptions
        include_traceback: Whether to include the traceback in the log message
        context: Additional context information for error messages
        propagate_exceptions: Exception types that should always be propagated
                            regardless of other settings
    
    Returns:
        Decorated function with error handling
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            exceptions_to_catch = exception_types or Exception
            context_info = f" [{context}]" if context else ""
            
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Check if this exception should be propagated
                if propagate_exceptions and isinstance(e, propagate_exceptions):
                    # Get the appropriate logging method
                    log_method = getattr(logger, log_level.lower(), logger.error)
                    log_method(f"Propagating exception in {func.__name__}{context_info}: {str(e)}")
                    raise
                
                # Check if this is an exception we should handle
                if not isinstance(e, exceptions_to_catch):
                    raise
                
                # Get the appropriate logging method
                log_method = getattr(logger, log_level.lower(), logger.error)
                
                # Prepare error message with context
                error_msg = f"Error in {func.__name__}{context_info}: {str(e)}"
                
                # Log the exception with or without traceback
                if include_traceback:
                    log_method(error_msg, exc_info=True)
                else:
                    log_method(error_msg)
                
                # Return the default value
                return default_return_value
        
        return wrapper
    
    return decorator

def with_recovery_strategy(strategies: Dict[Type[Exception], Callable], 
                          default_strategy: Optional[Callable] = None,
                          log_level: str = "error",
                          context: str = "",
                          propagate_unhandled: bool = True,
                          propagate_strategy_errors: bool = False):
    """
    Decorator that applies different recovery strategies based on exception type
    with improved error propagation
    
    Args:
        strategies: Dictionary mapping exception types to recovery functions
        default_strategy: Default recovery function if no matching exception type
        log_level: Logging level for exceptions
        context: Additional context information for error messages
        propagate_unhandled: Whether to propagate exceptions with no matching strategy
        propagate_strategy_errors: Whether to propagate errors that occur in recovery strategies
    
    Returns:
        Decorated function with error recovery strategies
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            context_info = f" [{context}]" if context else ""
            
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Get the appropriate logging method
                log_method = getattr(logger, log_level.lower(), logger.error)
                
                # Log the exception
                log_method(f"Error in {func.__name__}{context_info}: {str(e)}")
                
                # Find the most specific matching exception type
                for exc_type, strategy in strategies.items():
                    if isinstance(e, exc_type):
                        log_method(f"Applying recovery strategy for {exc_type.__name__}")
                        try:
                            return strategy(e, *args, **kwargs)
                        except Exception as strategy_error:
                            log_method(f"Error in recovery strategy for {exc_type.__name__}: {str(strategy_error)}")
                            if propagate_strategy_errors:
                                raise strategy_error from e
                            # If we don't propagate strategy errors, continue to default strategy or re-raise
                            break
                
                # If no matching strategy found or strategy failed, use default or re-raise
                if default_strategy:
                    log_method(f"Applying default recovery strategy")
                    try:
                        return default_strategy(e, *args, **kwargs)
                    except Exception as default_error:
                        log_method(f"Error in default recovery strategy: {str(default_error)}")
                        if propagate_strategy_errors:
                            raise default_error from e
                        # If we don't propagate strategy errors but do propagate unhandled, raise original
                        if propagate_unhandled:
                            raise e
                elif propagate_unhandled:
                    # No strategy found and no default, re-raise if configured to do so
                    raise
                
                # If we get here, we're not propagating the exception and have no successful strategy
                # Return None as a last resort
                return None
        
        return wrapper
    
    return decorator