# Unified retrieval system with optimized performance
import logging
import time
import os
from typing import List, Dict, Any, Optional, Tuple, Union

from utils.config_unified import retrieval_config, performance_config
from utils.document_processor_unified import DocumentProcessor
from utils.error_handling.enhanced_decorators import with_timing, with_error_tracking

# Setup logging
logger = logging.getLogger(__name__)

class UnifiedRetrievalSystem:
    """Unified system for retrieving relevant context from indexed documents"""
    
    def __init__(self, document_processor: Optional[DocumentProcessor] = None):
        """
        Initialize the retrieval system
        
        Args:
            document_processor: Document processor instance (creates new one if None)
        """
        self.document_processor = document_processor or DocumentProcessor()
        self.top_k = retrieval_config.top_k
        self.similarity_threshold = retrieval_config.similarity_threshold
        self.max_context_length = retrieval_config.max_context_length
        
        # Initialize metrics
        self.total_queries = 0
        self.query_times = []
        self.max_query_times = 100
        
        logger.info(f"Unified retrieval system initialized with top_k={self.top_k}")
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Get retrieval system metrics
        
        Returns:
            Dictionary with retrieval metrics
        """
        metrics = {
            "total_queries": self.total_queries
        }
        
        # Calculate average query time
        if self.query_times:
            metrics["avg_query_time"] = sum(self.query_times) / len(self.query_times)
            metrics["min_query_time"] = min(self.query_times)
            metrics["max_query_time"] = max(self.query_times)
        else:
            metrics["avg_query_time"] = 0.0
            metrics["min_query_time"] = 0.0
            metrics["max_query_time"] = 0.0
        
        # Add document processor metrics
        processor_metrics = self.document_processor.get_metrics()
        metrics.update({f"processor_{k}": v for k, v in processor_metrics.items()})
        
        return metrics
    
    def index_documents(self, file_paths: List[str]) -> None:
        """
        Index documents for retrieval
        
        Args:
            file_paths: List of paths to document files
        """
        self.document_processor.process_documents(file_paths)
        logger.info(f"Indexed {len(file_paths)} documents")
    
    def save_index(self, index_dir: str) -> None:
        """
        Save the search index to disk
        
        Args:
            index_dir: Directory to save the index
        """
        os.makedirs(index_dir, exist_ok=True)
        self.document_processor.save_index(index_dir)
    
    def load_index(self, index_dir: str) -> None:
        """
        Load a search index from disk
        
        Args:
            index_dir: Directory containing the index
        """
        self.document_processor.load_index(index_dir)
    
    @with_timing(threshold=0.5)
    def retrieve(self, query: str, top_k: Optional[int] = None) -> Tuple[str, float, int, List[float]]:
        """
        Retrieve relevant context for a query
        
        Args:
            query: Query string
            top_k: Number of top results to return (None for default)
            
        Returns:
            Tuple of (formatted context string, retrieval time in seconds, number of chunks, list of retrieval scores)
        """
        # Use default top_k if not specified
        top_k = top_k or self.top_k
        
        # Log the actual top_k value used and query (truncated for privacy/size)
        query_preview = query[:50] + "..." if len(query) > 50 else query
        logger.info(f"Retrieving context for query: '{query_preview}' with top_k={top_k}")
        
        # Search for relevant chunks
        start_time = time.time()
        try:
            # First check if index exists and is loaded
            if not self.document_processor.has_index():
                logger.warning("No index has been built. Process documents first.")
                results = []
            else:
                results = self.document_processor.search(query, top_k=top_k)
                
                # Filter by similarity threshold if enabled
                if self.similarity_threshold > 0:
                    pre_filter_count = len(results)
                    results = [r for r in results if r.get("score", 0) >= self.similarity_threshold]
                    filtered_count = pre_filter_count - len(results)
                    
                    # Log the filtering results
                    logger.info(f"Similarity filtering: {pre_filter_count} chunks → {len(results)} chunks (filtered {filtered_count} below threshold {self.similarity_threshold})")
                else:
                    # Log the actual number of chunks retrieved
                    logger.info(f"Retrieved {len(results)} chunks (no similarity threshold applied)")
        except ValueError as e:
            # Handle the case where no index has been built
            logger.warning(f"Search failed: {str(e)}")
            results = []
        except Exception as e:
            # Handle other exceptions
            logger.error(f"Error in search: {str(e)}")
            results = []
        
        # Update metrics
        self.total_queries += 1
        query_time = time.time() - start_time
        self.query_times.append(query_time)
        if len(self.query_times) > self.max_query_times:
            self.query_times = self.query_times[-self.max_query_times:]
        
        # Run deduplication after retrieval
        if len(results) > 1:
            try:
                # Simple deduplication based on text similarity
                deduplicated_results = []
                seen_texts = set()
                duplicates_found = 0
                
                for result in results:
                    text = result.get("text", "")
                    # Create a simplified version for comparison (lowercase, whitespace normalized)
                    simplified_text = " ".join(text.lower().split())
                    
                    # Skip if we've seen a very similar text
                    if any(self._text_similarity(simplified_text, seen) > 0.8 for seen in seen_texts):
                        logger.debug(f"Skipping duplicate chunk: {text[:50]}...")
                        duplicates_found += 1
                        continue
                    
                    # Add to results and mark as seen
                    deduplicated_results.append(result)
                    seen_texts.add(simplified_text)
                
                # Update results with deduplicated version
                logger.info(f"Deduplication: {len(results)} chunks u2192 {len(deduplicated_results)} chunks (removed {duplicates_found} duplicates)")
                results = deduplicated_results
            except Exception as e:
                logger.warning(f"Error during deduplication: {str(e)}")
                # Continue with original results if deduplication fails
        
        # Format context
        context = self._format_context(results)
        
        # Extract scores for progress tracking
        retrieval_scores = [result.get("score", 0.0) for result in results]
        
        # Calculate retrieval time
        retrieval_time = time.time() - start_time
        
        # Log the actual chunks sent to the LLM and performance metrics
        if context:
            logger.info(f"Retrieval complete: {len(results)} chunks, {len(context)} chars, {retrieval_time:.3f}s")
            # Log a preview of the context
            if logger.isEnabledFor(logging.DEBUG):
                context_preview = context[:200] + "..." if len(context) > 200 else context
                logger.debug(f"Context preview: {context_preview}")
        else:
            error_msg = f"Retrieved empty context for query: {query[:50]}..."
            logger.warning(error_msg)
            # Log to central error log
            try:
                from utils.error_logging import log_error
                log_error(error_msg, include_traceback=False)
            except ImportError:
                # Fallback to simple file logging if error_logging module is not available
                with open("/tmp/workapp2_errors.log", "a") as error_log:
                    error_log.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - WARNING - {error_msg}\n")
        
        # Return formatted context, retrieval time, number of chunks, and retrieval scores
        return context, query_time, len(results), retrieval_scores
    
    def _text_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate simple similarity between two texts
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score between 0 and 1
        """
        # Convert texts to sets of words
        words1 = set(text1.split())
        words2 = set(text2.split())
        
        # Calculate Jaccard similarity
        if not words1 or not words2:
            return 0.0
            
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        return intersection / union if union > 0 else 0.0
    
    def _format_context(self, results: List[Dict[str, Any]]) -> str:
        """
        Format search results into a context string
        
        Args:
            results: List of search results
            
        Returns:
            Formatted context string
        """
        if not results:
            return "No relevant information found."
        
        # Format each chunk with source information
        formatted_chunks = []
        total_length = 0
        
        for i, result in enumerate(results):
            # Format source information
            metadata = result.get("metadata", {})
            source = metadata.get("source", "Unknown source")
            page = metadata.get("page", "")
            page_info = f" (page {page})" if page else ""
            
            # Format chunk
            chunk_text = result.get("text", "No text available")
            formatted_chunk = f"[{i+1}] From {source}{page_info}:\n{chunk_text}\n"
            
            # Check if adding this chunk would exceed max context length
            if self.max_context_length > 0 and total_length + len(formatted_chunk) > self.max_context_length:
                # If this is the first chunk, include it anyway (truncated)
                if i == 0:
                    truncated_length = max(0, self.max_context_length - total_length - 3)
                    formatted_chunk = formatted_chunk[:truncated_length] + "..." if truncated_length > 0 else "..."
                    formatted_chunks.append(formatted_chunk)
                break
            
            # Add chunk
            formatted_chunks.append(formatted_chunk)
            total_length += len(formatted_chunk)
        
        # Join chunks
        return "\n".join(formatted_chunks)
    
    def retrieve_with_reranking(self, query: str, top_k: Optional[int] = None, rerank_top_k: Optional[int] = None) -> Tuple[str, float, int, List[float]]:
        """
        Retrieve relevant context with reranking for better results
        
        Args:
            query: Query string
            top_k: Number of top results to return (None for default)
            rerank_top_k: Number of results to rerank (None for default)
            
        Returns:
            Tuple of (formatted context string, retrieval time in seconds, number of chunks, list of retrieval scores)
        """
        # Use default values if not specified
        top_k = top_k or self.top_k
        rerank_top_k = rerank_top_k or (top_k * 3)  # Default to 3x top_k for reranking
        
        # Get initial results (more than needed for reranking)
        start_time = time.time()
        try:
            results = self.document_processor.search(query, top_k=rerank_top_k)
        except ValueError as e:
            # Handle the case where no index has been built
            logger.warning(f"Search failed: {str(e)}")
            return "No relevant information found.", time.time() - start_time, 0, []
        except Exception as e:
            # Handle other exceptions
            logger.error(f"Error in search: {str(e)}")
            return "No relevant information found.", time.time() - start_time, 0, []
        
        if not results or len(results) <= top_k:
            # If we have fewer results than requested, return them all
            return self.retrieve(query, top_k=top_k)
        
        # Rerank results if reranking is enabled
        if performance_config.enable_reranking:
            try:
                # Rerank using cross-encoder if available
                reranked_results = self._rerank_results(query, results)
                results = reranked_results[:top_k]
            except Exception as e:
                logger.error(f"Error in reranking: {str(e)}")
                # Fall back to initial results if reranking fails
                results = results[:top_k]
        else:
            # No reranking, just take top_k results
            results = results[:top_k]
        
        # Filter by similarity threshold if enabled
        if self.similarity_threshold > 0:
            results = [r for r in results if r["score"] >= self.similarity_threshold]
        
        # Format context
        context = self._format_context(results)
        
        # Extract scores for progress tracking
        retrieval_scores = [result.get("score", 0.0) for result in results]
        
        # Calculate retrieval time
        retrieval_time = time.time() - start_time
        
        # Update metrics
        self.total_queries += 1
        self.query_times.append(retrieval_time)
        if len(self.query_times) > self.max_query_times:
            self.query_times = self.query_times[-self.max_query_times:]
        
        # Return formatted context, retrieval time, number of chunks, and retrieval scores
        return context, retrieval_time, len(results), retrieval_scores
    
    def _rerank_results(self, query: str, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Rerank results using a cross-encoder model
        
        Args:
            query: Query string
            results: Initial search results
            
        Returns:
            Reranked results
        """
        try:
            from sentence_transformers import CrossEncoder
            
            # Initialize cross-encoder
            reranker_model = getattr(retrieval_config, 'reranker_model', 'cross-encoder/ms-marco-MiniLM-L-6-v2')
            cross_encoder = CrossEncoder(reranker_model)
            
            # Prepare pairs for reranking
            pairs = [(query, result["text"]) for result in results]
            
            # Get scores from cross-encoder
            scores = cross_encoder.predict(pairs)
            
            # Update scores in results
            for i, score in enumerate(scores):
                results[i]["score"] = float(score)
            
            # Sort by new scores
            reranked_results = sorted(results, key=lambda x: x["score"], reverse=True)
            
            return reranked_results
        except ImportError:
            logger.warning("CrossEncoder not available for reranking")
            return results
        except Exception as e:
            logger.error(f"Error in reranking: {str(e)}")
            return results
            
    def query(self, query: str, filtered_results: List[Dict[str, Any]] = None, use_enhanced_context: bool = False) -> Dict[str, Any]:
        """
        Process a query and return an answer with context
        
        Args:
            query: The user's question
            filtered_results: Pre-filtered search results (if None, will perform search)
            use_enhanced_context: Whether to use enhanced context processing
            
        Returns:
            Dictionary with answer, context, and metadata
        """
        try:
            from utils.text_processing.context_enhancement.enhanced_context_processor import EnhancedContextProcessor
            from utils.llm_service import LLMService
        except ImportError:
            logger.error("Failed to import required modules for query processing")
            return {
                "answer": "Error: Required modules not available",
                "context": "",
                "metadata": {"error": "Import error"}
            }
        
        # Get search results if not provided
        if filtered_results is None:
            try:
                results = self.document_processor.search(query, top_k=self.top_k)
                # Filter by similarity threshold
                filtered_results = [r for r in results if r["score"] >= self.similarity_threshold]
            except Exception as e:
                logger.error(f"Error in search: {str(e)}")
                return {
                    "answer": f"Error retrieving information: {str(e)}",
                    "context": "",
                    "metadata": {"error": str(e)}
                }
        
        # Process context
        if use_enhanced_context and filtered_results:
            try:
                # Use enhanced context processing if available
                processor = EnhancedContextProcessor()
                if hasattr(processor, 'process_with_metadata'):
                    result = processor.process_with_metadata(query, filtered_results)
                    context = result["context"]
                    metadata = result["metadata"]
                elif hasattr(processor, 'process'):
                    context = processor.process(query, filtered_results)
                    metadata = {"context_processing": "enhanced"}
                else:
                    # Fall back to basic context processing
                    context = "\n\n".join([result["text"] for result in filtered_results])
                    metadata = {"context_processing": "basic", "error": "EnhancedContextProcessor missing required methods"}
            except Exception as e:
                logger.error(f"Error in enhanced context processing: {str(e)}")
                # Fall back to basic context processing
                context = "\n\n".join([result["text"] for result in filtered_results])
                metadata = {"context_processing": "basic", "error": str(e)}
        else:
            # Basic context processing
            context = "\n\n".join([result["text"] for result in filtered_results])
            metadata = {"context_processing": "basic"}
        
        # Generate answer
        try:
            # Create LLM service if not available
            from utils.config_unified import app_config
            from utils.llm_service_enhanced import LLMService
            from utils.llm_service_enhanced import LLMService
            llm_service = LLMService(app_config.api_keys.get("openai", ""))
            answer_data = llm_service.generate_answer(query, context)
            
            return {
                "answer": answer_data.get("content", "No answer generated"),
                "context": context,
                "metadata": {
                    **metadata,
                    "model": answer_data.get("model", ""),
                    "tokens": answer_data.get("usage", {}).get("total_tokens", 0)
                }
            }
        except Exception as e:
            logger.error(f"Error generating answer: {str(e)}")
            return {
                "answer": f"Error generating answer: {str(e)}",
                "context": context,
                "metadata": {**metadata, "error": str(e)}
            }