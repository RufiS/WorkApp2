# Error and metrics logging module
import os
import time
import json
import logging
import traceback
import threading
from typing import Dict, Any, List, Optional, Union
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)

# Create a lock for thread-safe file access
log_lock = threading.RLock()

"""
WorkApp2 Logging Standards

This section documents the standardized logging approach for WorkApp2.
It provides examples and best practices for consistent error logging across the codebase.

Best Practices:
1. Always use both logger.* and log_* functions for complete coverage
2. Include source information in central logs for easier debugging
3. Use appropriate log levels (error, warning, info) consistently
4. Include stack traces for unexpected errors
5. Add contextual data to help with debugging

When to use which logging method:
- log_error: Critical errors, unexpected exceptions, security issues, data integrity problems
- log_warning: Potential issues that don't prevent operation, performance degradation, recoverable errors
- logger.error: Use alongside log_error() for immediate visibility in application logs
- logger.warning: Use alongside log_warning() for immediate visibility in application logs
- logger.info: Normal operational events, startup/shutdown information, configuration loading
- logger.debug: Detailed information for debugging, temporary logging during problem investigation
"""

def _log_to_file(log_entry: Dict[str, Any], log_path: str) -> None:
    """
    Internal function to write a log entry to a file with proper error handling
    
    Args:
        log_entry: The log entry dictionary to write
        log_path: Path to the log file
    """
    try:
        # Import resolve_path function for consistent path handling
        from utils.config_unified import resolve_path
        resolved_log_path = resolve_path(log_path, create_dir=True)
    except ImportError:
        # Fallback if resolve_path is not available
        resolved_log_path = log_path
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(resolved_log_path), exist_ok=True)
    
    # Write to log file with lock to prevent concurrent access issues
    with log_lock:
        try:
            with open(resolved_log_path, "a") as f:
                f.write(json.dumps(log_entry) + "\n")
        except Exception as e:
            # Fallback to temporary file if main log is inaccessible
            import tempfile
            fallback_path = os.path.join(tempfile.gettempdir(), "workapp2_errors.log")
            with open(fallback_path, "a") as f:
                f.write(json.dumps(log_entry) + "\n")
                f.write(f"Meta-error: Failed to write to primary log: {str(e)}\n")

def log_error(error_message: str, include_traceback: bool = False, error_type: str = "ERROR", 
             source: Optional[str] = None, additional_data: Optional[Dict[str, Any]] = None) -> None:
    """
    Log an error to the central error log file and application logger
    
    Args:
        error_message: The error message to log
        include_traceback: Whether to include the traceback
        error_type: Type of error (ERROR, WARNING, etc.)
        source: Source of the error (module, function, etc.)
        additional_data: Additional data to include in the log
    """
    try:
        from utils.config_unified import app_config, resolve_path
        error_log_path = resolve_path(app_config.error_log_path, create_dir=True)
    except ImportError:
        # Fallback if config is not available
        error_log_path = os.path.join(".", "logs", "workapp_errors.log")
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(error_log_path), exist_ok=True)
    
    # Create log entry
    timestamp = datetime.now().isoformat()
    log_entry = {
        "timestamp": timestamp,
        "type": error_type,
        "message": error_message
    }
    
    # Add source if provided
    if source:
        log_entry["source"] = source
    
    # Add traceback if requested
    if include_traceback:
        log_entry["traceback"] = traceback.format_exc()
    
    # Add additional data if provided
    if additional_data:
        log_entry["data"] = additional_data
    
    # Write to log file
    _log_to_file(log_entry, error_log_path)
    
    # Also log to application logger for consistency
    log_message = f"{error_message} [source: {source}]" if source else error_message
    logger.error(log_message, exc_info=include_traceback)

def log_warning(warning_message: str, include_traceback: bool = False, error_type: str = "WARNING", 
               source: Optional[str] = None, additional_data: Optional[Dict[str, Any]] = None) -> None:
    """
    Log a warning to the central error log file and application logger
    
    Args:
        warning_message: The warning message to log
        include_traceback: Whether to include the traceback
        error_type: Type of warning (WARNING, INFO, etc.)
        source: Source of the warning (module, function, etc.)
        additional_data: Additional data to include in the log
    """
    try:
        from utils.config_unified import app_config, resolve_path
        error_log_path = resolve_path(app_config.error_log_path, create_dir=True)
    except ImportError:
        # Fallback if config is not available
        error_log_path = os.path.join(".", "logs", "workapp_errors.log")
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(error_log_path), exist_ok=True)
    
    # Create log entry
    timestamp = datetime.now().isoformat()
    log_entry = {
        "timestamp": timestamp,
        "type": error_type,
        "message": warning_message
    }
    
    # Add source if provided
    if source:
        log_entry["source"] = source
    
    # Add traceback if requested
    if include_traceback:
        log_entry["traceback"] = traceback.format_exc()
    
    # Add additional data if provided
    if additional_data:
        log_entry["data"] = additional_data
    
    # Write to log file
    _log_to_file(log_entry, error_log_path)
    
    # Also log to application logger for consistency
    log_message = f"{warning_message} [source: {source}]" if source else warning_message
    logger.warning(log_message, exc_info=include_traceback)

class QueryLogger:
    """
    Logger for query metrics and zero-hit queries
    """
    def __init__(self, log_dir: str = "./logs"):
        """
        Initialize the query logger
        
        Args:
            log_dir: Directory to store log files
        """
        try:
            # Import resolve_path function for consistent path handling
            from utils.config_unified import resolve_path
            self.log_dir = resolve_path(log_dir, create_dir=True)
        except ImportError:
            # Fallback if resolve_path is not available
            self.log_dir = log_dir
            # Create log directory if it doesn't exist
            os.makedirs(self.log_dir, exist_ok=True)
            
        self.query_log_path = os.path.join(self.log_dir, "query_metrics.log")
        self.zero_hit_log_path = os.path.join(self.log_dir, "zero_hit_queries.log")
    
    def log_query(self, query: str, latency: float, hit_count: int, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Log query metrics
        
        Args:
            query: The query string
            latency: Query processing time in seconds
            hit_count: Number of results returned
            metadata: Additional metadata to log
        """
        try:
            # Create log entry
            timestamp = datetime.now().isoformat()
            log_entry = {
                "timestamp": timestamp,
                "query": query,
                "latency": round(latency, 4),
                "hit_count": hit_count
            }
            
            # Add metadata if provided
            if metadata:
                log_entry["metadata"] = metadata
            
            # Write to log file
            _log_to_file(log_entry, self.query_log_path)
            
            # Log zero-hit queries separately if enabled
            if hit_count == 0:
                self.log_zero_hit_query(query, metadata)
        except Exception as e:
            logger.error(f"Error logging query metrics: {str(e)}")
            log_error(f"Error logging query metrics: {str(e)}", include_traceback=True, source="QueryLogger.log_query")
    
    def log_zero_hit_query(self, query: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Log zero-hit queries for analysis
        
        Args:
            query: The query string that returned no results
            metadata: Additional metadata to log
        """
        try:
            # Create log entry
            timestamp = datetime.now().isoformat()
            log_entry = {
                "timestamp": timestamp,
                "query": query
            }
            
            # Add metadata if provided
            if metadata:
                log_entry["metadata"] = metadata
            
            # Write to log file
            _log_to_file(log_entry, self.zero_hit_log_path)
        except Exception as e:
            logger.error(f"Error logging zero-hit query: {str(e)}")
            log_error(f"Error logging zero-hit query: {str(e)}", include_traceback=True, source="QueryLogger.log_zero_hit_query")
    
    def log_warning(self, warning_message: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Log a warning related to query processing
        
        Args:
            warning_message: The warning message to log
            metadata: Additional metadata to log
        """
        try:
            # Create log entry
            timestamp = datetime.now().isoformat()
            log_entry = {
                "timestamp": timestamp,
                "type": "WARNING",
                "message": warning_message
            }
            
            # Add metadata if provided
            if metadata:
                log_entry["metadata"] = metadata
            
            # Write to log file
            warning_log_path = os.path.join(self.log_dir, "query_warnings.log")
            _log_to_file(log_entry, warning_log_path)
                    
            # Also log to application logger and central error log
            logger.warning(f"Query warning: {warning_message}")
            log_warning(warning_message, source="QueryLogger", additional_data=metadata)
        except Exception as e:
            logger.error(f"Error logging query warning: {str(e)}")
            log_error(f"Error logging query warning: {str(e)}", include_traceback=True, source="QueryLogger.log_warning")
    
    def log_error(self, error_message: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Log an error related to query processing
        
        Args:
            error_message: The error message to log
            metadata: Additional metadata to log
        """
        try:
            # Create log entry
            timestamp = datetime.now().isoformat()
            log_entry = {
                "timestamp": timestamp,
                "type": "ERROR",
                "message": error_message
            }
            
            # Add metadata if provided
            if metadata:
                log_entry["metadata"] = metadata
            
            # Write to log file
            error_log_path = os.path.join(self.log_dir, "query_errors.log")
            _log_to_file(log_entry, error_log_path)
                    
            # Also log to application logger and central error log
            logger.error(f"Query error: {error_message}")
            log_error(error_message, include_traceback=False, error_type="QUERY_ERROR", source="QueryLogger", additional_data=metadata)
        except Exception as e:
            logger.error(f"Error logging query error: {str(e)}")
            log_error(f"Error logging query error: {str(e)}", include_traceback=True, source="QueryLogger.log_error")
    
    def analyze_zero_hit_queries(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Analyze recent zero-hit queries
        
        Args:
            limit: Maximum number of queries to analyze
            
        Returns:
            List of zero-hit query entries
        """
        try:
            if not os.path.exists(self.zero_hit_log_path):
                return []
            
            # Read recent zero-hit queries
            entries = []
            with open(self.zero_hit_log_path, "r") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        entries.append(entry)
                    except json.JSONDecodeError:
                        continue
            
            # Return most recent entries up to limit
            return sorted(entries, key=lambda x: x.get("timestamp", ""), reverse=True)[:limit]
        except Exception as e:
            logger.error(f"Error analyzing zero-hit queries: {str(e)}")
            log_error(f"Error analyzing zero-hit queries: {str(e)}", include_traceback=True, source="QueryLogger.analyze_zero_hit_queries")
            return []
    
    def get_query_metrics(self, days: int = 7) -> Dict[str, Any]:
        """
        Get query metrics for the specified time period
        
        Args:
            days: Number of days to analyze
            
        Returns:
            Dictionary with query metrics
        """
        try:
            if not os.path.exists(self.query_log_path):
                return {
                    "total_queries": 0,
                    "zero_hit_rate": 0.0,
                    "avg_latency": 0.0,
                    "avg_hit_count": 0.0
                }
            
            # Calculate cutoff timestamp
            cutoff = datetime.now().timestamp() - (days * 24 * 60 * 60)
            
            # Read and process query logs
            total_queries = 0
            zero_hit_queries = 0
            total_latency = 0.0
            total_hits = 0
            
            with open(self.query_log_path, "r") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        timestamp = datetime.fromisoformat(entry.get("timestamp", "")).timestamp()
                        
                        # Skip entries older than cutoff
                        if timestamp < cutoff:
                            continue
                        
                        total_queries += 1
                        total_latency += entry.get("latency", 0.0)
                        hits = entry.get("hit_count", 0)
                        total_hits += hits
                        
                        if hits == 0:
                            zero_hit_queries += 1
                    except (json.JSONDecodeError, ValueError):
                        continue
            
            # Calculate metrics
            zero_hit_rate = zero_hit_queries / total_queries if total_queries > 0 else 0.0
            avg_latency = total_latency / total_queries if total_queries > 0 else 0.0
            avg_hit_count = total_hits / total_queries if total_queries > 0 else 0.0
            
            return {
                "total_queries": total_queries,
                "zero_hit_queries": zero_hit_queries,
                "zero_hit_rate": round(zero_hit_rate, 4),
                "avg_latency": round(avg_latency, 4),
                "avg_hit_count": round(avg_hit_count, 2)
            }
        except Exception as e:
            logger.error(f"Error getting query metrics: {str(e)}")
            log_error(f"Error getting query metrics: {str(e)}", include_traceback=True, source="QueryLogger.get_query_metrics")
            return {
                "total_queries": 0,
                "zero_hit_rate": 0.0,
                "avg_latency": 0.0,
                "avg_hit_count": 0.0,
                "error": str(e)
            }

# Create global query logger instance
try:
    from utils.config_unified import resolve_path
    query_logger = QueryLogger(log_dir=resolve_path(os.path.join(".", "logs"), create_dir=True))
except ImportError:
    query_logger = QueryLogger(log_dir=os.path.join(".", "logs"))