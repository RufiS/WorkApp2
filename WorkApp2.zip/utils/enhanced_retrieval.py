# WorkApp2 Progress: Last completed Retrieval-3 (Retrieval System)
# Next pending LLM-1 (LLM Service)
# Enhanced retrieval module
import os
import numpy as np
import faiss
import logging
import time
from typing import List, Dict, Any, Tuple, Optional
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from utils.config_unified import retrieval_config, performance_config, resolve_path
from utils.error_handling.decorators import with_timing, with_advanced_retry

# Import query logger
from utils.error_logging import query_logger

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EnhancedRetrieval:
    """Enhanced retrieval system with hybrid search and reranking"""
    
    def __init__(self):
        """Initialize the enhanced retrieval system"""
        self.bm25_index = None
        self.tfidf_vectorizer = None
        self.tokenized_corpus = None
        self.corpus = None
        self.chunk_ids = None
        self.use_hybrid = retrieval_config.enhanced_mode
        self.use_mmr = performance_config.enable_reranking
        self.enable_keyword_fallback = performance_config.enable_keyword_fallback  # Use from performance_config
    
    @with_timing(threshold=0.5)
    def build_bm25_index(self, chunks: List[Dict[str, Any]]) -> None:
        """
        Build a BM25 index from document chunks
        
        Args:
            chunks: List of document chunks
        """
        # Sanity check: Validate input
        if chunks is None:
            logger.error("Cannot build BM25 index with None chunks")
            raise ValueError("chunks parameter cannot be None")
            
        if not isinstance(chunks, list):
            logger.error(f"chunks must be a list, got {type(chunks)}")
            raise TypeError(f"chunks must be a list, got {type(chunks)}")
        
        if not chunks:
            logger.warning("No chunks provided for BM25 indexing")
            return
        
        try:
            # Extract texts and IDs
            self.corpus = []
            self.chunk_ids = []
            invalid_chunks = 0
            
            for i, chunk in enumerate(chunks):
                # Sanity check: Validate chunk format
                if not isinstance(chunk, dict):
                    logger.warning(f"Chunk at index {i} is not a dictionary: {type(chunk)}")
                    invalid_chunks += 1
                    continue
                    
                if "text" not in chunk:
                    logger.warning(f"Chunk at index {i} has no 'text' field")
                    invalid_chunks += 1
                    continue
                    
                if not isinstance(chunk["text"], str):
                    logger.warning(f"Chunk 'text' at index {i} is not a string: {type(chunk['text'])}")
                    invalid_chunks += 1
                    continue
                
                # Extract text and ID
                self.corpus.append(chunk["text"])
                
                # Use id if available, otherwise generate one
                if "id" in chunk and chunk["id"]:
                    self.chunk_ids.append(chunk["id"])
                else:
                    # Generate a synthetic ID
                    self.chunk_ids.append(f"chunk-{i}")
            
            # Sanity check: Log warning if too many invalid chunks
            if invalid_chunks > 0:
                logger.warning(f"Found {invalid_chunks} invalid chunks out of {len(chunks)} total chunks")
                if invalid_chunks / len(chunks) > 0.5:
                    logger.error(f"More than 50% of chunks are invalid ({invalid_chunks}/{len(chunks)})")
                    if len(self.corpus) == 0:
                        raise ValueError("No valid chunks for BM25 indexing")
            
            # Tokenize corpus
            self.tokenized_corpus = [text.lower().split() for text in self.corpus]
            
            # Sanity check: Verify tokenization
            empty_tokens = sum(1 for tokens in self.tokenized_corpus if not tokens)
            if empty_tokens > 0:
                logger.warning(f"Found {empty_tokens} chunks with no tokens after tokenization")
            
            # Build BM25 index
            self.bm25_index = BM25Okapi(self.tokenized_corpus)
            
            # Sanity check: Verify BM25 index
            if not hasattr(self.bm25_index, 'get_scores'):
                logger.error("BM25 index initialization failed: missing 'get_scores' method")
                raise RuntimeError("BM25 index initialization failed")
            
            # Build TF-IDF vectorizer for query expansion
            self.tfidf_vectorizer = TfidfVectorizer()
            self.tfidf_vectorizer.fit(self.corpus)
            
            # Sanity check: Verify TF-IDF vectorizer
            if not hasattr(self.tfidf_vectorizer, 'transform'):
                logger.error("TF-IDF vectorizer initialization failed: missing 'transform' method")
                raise RuntimeError("TF-IDF vectorizer initialization failed")
            
            logger.info(f"Built BM25 index with {len(self.corpus)} documents")
        except Exception as e:
            logger.error(f"Error building BM25 index: {str(e)}")
            raise
    
    @with_timing(threshold=0.5)
    def hybrid_search(self, query: str, vector_results: List[Dict[str, Any]], top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Perform hybrid search combining vector search and BM25
        
        Args:
            query: Query string
            vector_results: Results from vector search
            top_k: Number of results to return
            
        Returns:
            Combined and reranked results with fallback_info field indicating if fallback was used
        """
        # Log query and hit count for instrumentation
        start_time = time.time()
        query_preview = query[:50] + "..." if len(query) > 50 else query
        logger.info(f"Hybrid search for query: '{query_preview}' with {len(vector_results)} vector results, requesting top_k={top_k}")
        
        # Initialize fallback info
        fallback_info = {
            "used_fallback": False,
            "fallback_reason": None,
            "original_method": "hybrid"
        }
        
        if not self.bm25_index or not self.corpus:
            logger.warning("BM25 index not built, falling back to vector search only")
            # Ensure we don't exceed the available results
            safe_top_k = min(top_k, len(vector_results))
            # Log latency
            latency = time.time() - start_time
            logger.info(f"Hybrid search completed in {latency:.4f}s, returning {safe_top_k} results (vector-only)")
            
            # Update fallback info
            fallback_info["used_fallback"] = True
            fallback_info["fallback_reason"] = "bm25_index_not_built"
            
            # Add fallback info to results
            results = vector_results[:safe_top_k]
            for result in results:
                result["fallback_info"] = fallback_info
            
            # Log query metrics if enabled
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=latency,
                    hit_count=safe_top_k,
                    metadata={
                        "search_type": "vector_only",
                        "fallback_reason": "bm25_index_not_built"
                    }
                )
                
                # Log warning for monitoring if fallback was used
                if performance_config.log_zero_hit_queries:
                    query_logger.log_warning(
                        f"Hybrid search fallback: BM25 index not built for query '{query_preview}'",
                        metadata={
                            "query": query,
                            "fallback_type": "bm25_index_not_built",
                            "search_type": "hybrid_search"
                        }
                    )
            
            # Return results with clear indication of fallback
            return results
        
        try:
            # Tokenize query
            tokenized_query = query.lower().split()
            
            # Get BM25 scores
            bm25_scores = self.bm25_index.get_scores(tokenized_query)
            
            # Normalize BM25 scores to [0, 1]
            max_bm25_score = max(bm25_scores) if bm25_scores.any() else 1.0
            normalized_bm25_scores = bm25_scores / max_bm25_score if max_bm25_score > 0 else bm25_scores
            
            # Create a mapping of chunk_id to BM25 score
            bm25_score_map = {chunk_id: score for chunk_id, score in zip(self.chunk_ids, normalized_bm25_scores)}
            
            # Get vector search scores and normalize them
            vector_score_map = {result["id"]: result["score"] for result in vector_results}
            max_vector_score = max(vector_score_map.values()) if vector_score_map else 1.0
            normalized_vector_scores = {k: v / max_vector_score for k, v in vector_score_map.items()}
            
            # Combine scores with weighting
            alpha = retrieval_config.vector_weight  # Weight for vector scores (0.0 to 1.0)
            beta = 1.0 - alpha  # Weight for BM25 scores
            
            combined_results = []
            for result in vector_results:
                chunk_id = result["id"]
                vector_score = normalized_vector_scores.get(chunk_id, 0.0)
                bm25_score = bm25_score_map.get(chunk_id, 0.0)
                
                # Combine scores
                combined_score = (alpha * vector_score) + (beta * bm25_score)
                
                # Create combined result
                combined_result = result.copy()
                combined_result["score"] = combined_score
                combined_result["vector_score"] = vector_score
                combined_result["bm25_score"] = bm25_score
                combined_result["fallback_info"] = fallback_info  # Add fallback info
                
                combined_results.append(combined_result)
            
            # Sort by combined score
            combined_results.sort(key=lambda x: x["score"], reverse=True)
            
            # Apply MMR reranking if enabled
            if self.use_mmr:
                combined_results = self.mmr_reranking(query, combined_results, top_k)
            else:
                # Ensure we don't exceed the available results
                safe_top_k = min(top_k, len(combined_results))
                combined_results = combined_results[:safe_top_k]
            
            # Log latency and hit count
            latency = time.time() - start_time
            logger.info(f"Hybrid search completed in {latency:.4f}s, returning {len(combined_results)} results")
            
            # Log query metrics if enabled
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=latency,
                    hit_count=len(combined_results),
                    metadata={
                        "search_type": "hybrid",
                        "vector_weight": retrieval_config.vector_weight,
                        "mmr_applied": self.use_mmr
                    }
                )
            
            return combined_results
        except Exception as e:
            logger.error(f"Error in hybrid search: {str(e)}")
            # Fall back to vector search with safe top_k
            safe_top_k = min(top_k, len(vector_results))
            # Log latency and error
            latency = time.time() - start_time
            logger.info(f"Hybrid search failed in {latency:.4f}s, falling back to vector search with {safe_top_k} results")
            
            # Update fallback info
            fallback_info["used_fallback"] = True
            fallback_info["fallback_reason"] = f"hybrid_search_error: {str(e)}"
            
            # Add fallback info to results
            results = vector_results[:safe_top_k]
            for result in results:
                result["fallback_info"] = fallback_info
                
            # Log warning for monitoring if fallback was used
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=latency,
                    hit_count=safe_top_k,
                    metadata={
                        "search_type": "vector_only",
                        "fallback_reason": f"hybrid_search_error: {str(e)}",
                        "error": True
                    }
                )
                
                # Log detailed error information
                if performance_config.log_zero_hit_queries:
                    query_logger.log_error(
                        f"Hybrid search error for query '{query_preview}': {str(e)}",
                        metadata={
                            "query": query,
                            "error_type": type(e).__name__,
                            "error_message": str(e),
                            "search_type": "hybrid_search"
                        }
                    )
            
            # Return results with clear indication of fallback
            return results
    
    @with_timing(threshold=0.5)
    def mmr_reranking(self, query: str, results: List[Dict[str, Any]], top_k: int = 10, 
                     lambda_param: float = 0.7) -> List[Dict[str, Any]]:
        """
        Apply Maximal Marginal Relevance reranking to diversify results
        
        Args:
            query: Query string
            results: Search results to rerank
            top_k: Number of results to return
            lambda_param: Trade-off between relevance and diversity (0.0 to 1.0)
            
        Returns:
            Reranked results
        """
        # Log query and hit count for instrumentation
        start_time = time.time()
        query_preview = query[:50] + "..." if len(query) > 50 else query
        logger.info(f"MMR reranking for query: '{query_preview}' with {len(results)} results, requesting top_k={top_k}")
        
        if not results:
            logger.warning("No results to rerank")
            latency = time.time() - start_time
            logger.info(f"MMR reranking completed in {latency:.4f}s, returning 0 results")
            return []
        
        # Ensure top_k doesn't exceed available results
        safe_top_k = min(top_k, len(results))
        if safe_top_k < top_k:
            logger.info(f"Adjusted top_k from {top_k} to {safe_top_k} based on available results")
        
        try:
            # Extract texts and scores
            texts = [result["text"] for result in results]
            scores = np.array([result["score"] for result in results])
            
            # Create TF-IDF vectors for texts
            tfidf_matrix = self.tfidf_vectorizer.transform(texts).toarray()
            
            # Compute query vector
            query_vec = self.tfidf_vectorizer.transform([query]).toarray()[0]
            
            # Normalize vectors for cosine similarity
            query_vec_norm = query_vec / np.linalg.norm(query_vec) if np.linalg.norm(query_vec) > 0 else query_vec
            tfidf_matrix_norm = tfidf_matrix / np.linalg.norm(tfidf_matrix, axis=1, keepdims=True)
            
            # Calculate similarity between query and documents
            sim_query_docs = np.dot(tfidf_matrix_norm, query_vec_norm)
            
            # Initialize selected and remaining indices
            selected_indices = []
            remaining_indices = list(range(len(results)))
            
            # Select the first document with highest similarity to query
            first_idx = np.argmax(sim_query_docs)
            selected_indices.append(first_idx)
            remaining_indices.remove(first_idx)
            
            # Select remaining documents using MMR
            for _ in range(min(safe_top_k - 1, len(results) - 1)):
                if not remaining_indices:
                    break
                    
                # Calculate similarity between each remaining document and selected documents
                max_mmr_score = -np.inf
                max_mmr_idx = -1
                
                for idx in remaining_indices:
                    # Relevance term: similarity to query
                    relevance = sim_query_docs[idx]
                    
                    # Diversity term: maximum similarity to any selected document
                    if selected_indices:
                        selected_docs_vectors = tfidf_matrix_norm[selected_indices]
                        doc_vector = tfidf_matrix_norm[idx].reshape(1, -1)
                        sim_doc_docs = np.dot(selected_docs_vectors, doc_vector.T).flatten()
                        diversity = np.max(sim_doc_docs)
                    else:
                        diversity = 0.0
                    
                    # MMR score
                    mmr_score = lambda_param * relevance - (1.0 - lambda_param) * diversity
                    
                    if mmr_score > max_mmr_score:
                        max_mmr_score = mmr_score
                        max_mmr_idx = idx
                
                if max_mmr_idx != -1:
                    selected_indices.append(max_mmr_idx)
                    remaining_indices.remove(max_mmr_idx)
            
            # Rerank results based on selected indices
            reranked_results = [results[idx] for idx in selected_indices]
            
            # Log latency and hit count
            latency = time.time() - start_time
            logger.info(f"MMR reranking completed in {latency:.4f}s, selected {len(reranked_results)} diverse results")
            return reranked_results
        except Exception as e:
            logger.error(f"Error in MMR reranking: {str(e)}")
            # Fall back to original ranking with safe top_k
            safe_top_k = min(top_k, len(results))
            # Log latency and error
            latency = time.time() - start_time
            logger.info(f"MMR reranking failed in {latency:.4f}s, falling back to original ranking with {safe_top_k} results")
            return results[:safe_top_k]
    
    @with_timing(threshold=0.5)
    @with_advanced_retry(max_attempts=3, backoff_factor=1.5, exception_types=[IOError, OSError])
    def keyword_fallback_search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Perform keyword-based search as a fallback when vector search returns no results
        
        Args:
            query: Query string
            top_k: Number of results to return
            
        Returns:
            List of relevant chunks based on keyword matching with error information
            
        Raises:
            ValueError: If BM25 index is not built or inputs are invalid
            RuntimeError: If BM25 search fails with data inconsistency
            IOError: If there's an I/O error during search
        """
        # Initialize error tracking
        error_info = {
            "has_error": False,
            "error_type": None,
            "error_message": None,
            "search_type": "keyword_fallback"
        }
        
        # Log query for instrumentation
        start_time = time.time()
        query_preview = query[:50] + "..." if len(query) > 50 else query
        logger.info(f"Keyword fallback search for query: '{query_preview}', requesting top_k={top_k}")
        
        # Validate inputs with proper error propagation
        if not query or not isinstance(query, str):
            error_msg = f"Invalid query: {query}"
            logger.error(error_msg)
            # Log to central error log
            from utils.error_logging import log_error
            log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="VALIDATION_ERROR")
            # Raise a proper exception instead of silent return
            raise ValueError(error_msg)
            
        if not isinstance(top_k, int) or top_k <= 0:
            error_msg = f"Invalid top_k value: {top_k}"
            logger.error(error_msg)
            # Log to central error log
            from utils.error_logging import log_error
            log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="VALIDATION_ERROR")
            # Raise a proper exception instead of silent return
            raise ValueError(error_msg)
        
        # Verify BM25 index is built with proper error propagation
        if not self.bm25_index or not self.corpus:
            error_msg = "BM25 index not built, cannot perform keyword fallback search"
            logger.error(error_msg)
            latency = time.time() - start_time
            logger.info(f"Keyword fallback search failed in {latency:.4f}s: BM25 index not built")
            
            # Log to central error log
            from utils.error_logging import log_error
            log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="INDEX_ERROR")
            
            # Update error info
            error_info["has_error"] = True
            error_info["error_type"] = "index_not_built"
            error_info["error_message"] = error_msg
            
            # Log query metrics if enabled
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=latency,
                    hit_count=0,
                    metadata={
                        "search_type": "keyword_fallback",
                        "error": True,
                        "error_type": "index_not_built"
                    }
                )
            
            # Raise a proper exception instead of silent return
            raise ValueError(error_msg)
        
        # Verify corpus and chunk_ids are aligned with proper error propagation
        if len(self.corpus) != len(self.chunk_ids):
            error_msg = f"Corpus and chunk_ids length mismatch: corpus={len(self.corpus)}, chunk_ids={len(self.chunk_ids)}"
            logger.error(error_msg)
            
            # Log to central error log
            from utils.error_logging import log_error
            log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="DATA_INTEGRITY_ERROR")
            
            # Update error info
            error_info["has_error"] = True
            error_info["error_type"] = "data_mismatch"
            error_info["error_message"] = error_msg
            
            # Log query metrics if enabled
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=time.time() - start_time,
                    hit_count=0,
                    metadata={
                        "search_type": "keyword_fallback",
                        "error": True,
                        "error_type": "data_mismatch"
                    }
                )
            
            # Raise a proper exception instead of silent return
            raise RuntimeError(error_msg)
        
        try:
            # Tokenize query
            tokenized_query = query.lower().split()
            
            # Verify query has tokens with proper error propagation
            if not tokenized_query:
                error_msg = f"Query '{query}' has no tokens after tokenization"
                logger.warning(error_msg)
                
                # Log to central error log
                from utils.error_logging import log_warning
                log_warning(error_msg, source="EnhancedRetrieval.keyword_fallback_search")
                
                # Update error info
                error_info["has_error"] = True
                error_info["error_type"] = "empty_tokens"
                error_info["error_message"] = error_msg
                
                # Log query metrics if enabled
                if performance_config.log_query_metrics:
                    query_logger.log_query(
                        query=query,
                        latency=time.time() - start_time,
                        hit_count=0,
                        metadata={
                            "search_type": "keyword_fallback",
                            "error": True,
                            "error_type": "empty_tokens"
                        }
                    )
                
                # Return empty results with error info
                return self._create_empty_results_with_error(error_info)
            
            # Get BM25 scores
            bm25_scores = self.bm25_index.get_scores(tokenized_query)
            
            # Verify scores array with proper error propagation
            if bm25_scores is None or not isinstance(bm25_scores, np.ndarray):
                error_msg = f"BM25 returned invalid scores: {type(bm25_scores)}"
                logger.error(error_msg)
                
                # Log to central error log
                from utils.error_logging import log_error
                log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="SEARCH_ERROR")
                
                # Update error info
                error_info["has_error"] = True
                error_info["error_type"] = "invalid_scores"
                error_info["error_message"] = error_msg
                
                # Log query metrics if enabled
                if performance_config.log_query_metrics:
                    query_logger.log_query(
                        query=query,
                        latency=time.time() - start_time,
                        hit_count=0,
                        metadata={
                            "search_type": "keyword_fallback",
                            "error": True,
                            "error_type": "invalid_scores"
                        }
                    )
                
                # Raise a proper exception instead of silent return
                raise RuntimeError(error_msg)
                
            if len(bm25_scores) != len(self.corpus):
                error_msg = f"BM25 scores length mismatch: scores={len(bm25_scores)}, corpus={len(self.corpus)}"
                logger.error(error_msg)
                
                # Log to central error log
                from utils.error_logging import log_error
                log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="DATA_INTEGRITY_ERROR")
                
                # Update error info
                error_info["has_error"] = True
                error_info["error_type"] = "scores_mismatch"
                error_info["error_message"] = error_msg
                
                # Log query metrics if enabled
                if performance_config.log_query_metrics:
                    query_logger.log_query(
                        query=query,
                        latency=time.time() - start_time,
                        hit_count=0,
                        metadata={
                            "search_type": "keyword_fallback",
                            "error": True,
                            "error_type": "scores_mismatch"
                        }
                    )
                
                # Raise a proper exception instead of silent return
                raise RuntimeError(error_msg)
            
            # Check for empty scores array with proper error handling
            if len(bm25_scores) == 0:
                error_msg = "BM25 returned empty scores array"
                logger.warning(error_msg)
                
                # Log to central error log
                from utils.error_logging import log_warning
                log_warning(error_msg, source="EnhancedRetrieval.keyword_fallback_search")
                
                # Update error info
                error_info["has_error"] = True
                error_info["error_type"] = "empty_scores"
                error_info["error_message"] = error_msg
                
                # Log query metrics if enabled
                if performance_config.log_query_metrics:
                    query_logger.log_query(
                        query=query,
                        latency=time.time() - start_time,
                        hit_count=0,
                        metadata={
                            "search_type": "keyword_fallback",
                            "error": True,
                            "error_type": "empty_scores"
                        }
                    )
                
                # Return empty results with error info
                return self._create_empty_results_with_error(error_info)
                
            # Continue with normal processing here
            # ... (rest of the function code)
            
        except Exception as e:
            # Handle any exceptions that might occur
            error_msg = f"Error in keyword fallback search: {str(e)}"
            logger.error(error_msg)
            
            # Log to central error log
            try:
                from utils.error_logging import log_error
                log_error(error_msg, source="EnhancedRetrieval.keyword_fallback_search", error_type="SEARCH_ERROR")
            except ImportError:
                logger.error("Could not import log_error from error_logging module")
            
            # Update error info
            error_info["has_error"] = True
            error_info["error_type"] = "search_exception"
            error_info["error_message"] = error_msg
            
            # Log query metrics if enabled
            if performance_config.log_query_metrics:
                query_logger.log_query(
                    query=query,
                    latency=time.time() - start_time,
                    hit_count=0,
                    metadata={
                        "search_type": "keyword_fallback",
                        "error": True,
                        "error_type": "search_exception"
                    }
                )
            
            # Return empty results with error info
            return self._create_empty_results_with_error(error_info)
    def _create_empty_results_with_error(self, error_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Create an empty results list with error information
        
        Args:
            error_info: Dictionary with error information
            
        Returns:
            Empty list with error information
        """
        # Log the error for monitoring
        if error_info.get("has_error", False):
            logger.warning(f"Returning empty results due to error: {error_info.get('error_type', 'unknown')} - {error_info.get('error_message', 'No message')}")
            
            # Log to central error log
            try:
                from utils.error_logging import log_warning
                log_warning(
                    f"Search returned empty results: {error_info.get('error_message', 'No message')}",
                    source="EnhancedRetrieval._create_empty_results_with_error",
                    additional_data={
                        "error_type": error_info.get("error_type"),
                        "search_type": error_info.get("search_type", "unknown")
                    }
                )
            except ImportError:
                # Fallback if error_logging module is not available
                logger.warning("Could not import log_warning from error_logging module")
            
            # Log to query logger if enabled
            if performance_config.log_query_metrics:
                try:
                    query_logger.log_query(
                        query=error_info.get("query", "unknown"),
                        latency=error_info.get("latency", 0.0),
                        hit_count=0,
                        metadata={
                            "search_type": error_info.get("search_type", "unknown"),
                            "error": True,
                            "error_type": error_info.get("error_type"),
                            "error_message": error_info.get("error_message")
                        }
                    )
                except Exception as e:
                    logger.warning(f"Failed to log query metrics: {str(e)}")
        
        # Return empty list with fallback info
        return [{
            "id": "error",
            "text": f"Error: {error_info.get('error_message', 'Unknown error')}",
            "score": 0.0,
            "search_type": error_info.get("search_type", "unknown"),
            "fallback_info": {
                "used_fallback": True,
                "fallback_reason": error_info.get("error_type", "unknown_error"),
                "original_method": "vector",
                "error": True,
                "error_details": error_info
            }
        }] if error_info.get("include_error_placeholder", False) else []